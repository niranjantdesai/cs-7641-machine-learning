import numpy as np

loss = []
loss.append(0.1)

pass