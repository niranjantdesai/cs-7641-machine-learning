"""
Implementation of randomized hill climbing, simulated annealing, and genetic algorithm to
find optimal weights to a neural network that is classifying abalone as having either fewer
or more than 15 rings.

Based on AbaloneTest.java by Hannah Lau
"""
from __future__ import with_statement
import os
import csv
import time

import sys
sys.path.insert(0, '../bin')
from func.nn.backprop import BackPropagationNetworkFactory
from shared import SumOfSquaresError, DataSet, Instance
from opt.example import NeuralNetworkOptimizationProblem

import opt.RandomizedHillClimbing as RandomizedHillClimbing
import opt.SimulatedAnnealing as SimulatedAnnealing
import opt.ga.StandardGeneticAlgorithm as StandardGeneticAlgorithm

INPUT_FILE_TRAIN = os.path.join("..", "src", "opt", "test", "train.csv")
INPUT_FILE_TEST = os.path.join("..", "src", "opt", "test", "test.csv")

INPUT_LAYER = 30
HIDDEN_LAYER1 = 5
HIDDEN_LAYER2 = 2
OUTPUT_LAYER = 1
TRAINING_ITERATIONS = 1000


def initialize_instances(input_file):
    """Read the abalone.txt CSV data into a list of instances."""
    instances = []

    # Read in the abalone.txt CSV file
    with open(input_file, "r") as file:
        reader = csv.reader(file)

        for row in reader:
            instance = Instance([float(value) for value in row[:-1]])
            instance.setLabel(Instance(float(row[-1])))
            instances.append(instance)

    return instances
    
    
def save_list(data, input_file):
    with open(input_file, 'w') as csvfile:
        #writer = csv.writer(csvfile, delimiter=',')
        #
        #for x in data:
        #    writer.writerow([x])
        for x in data:
            csvfile.write("%s\n" % x)


def train(oa, network, oaName, instances, measure):
    """Train a given network on a set of instances.

    :param OptimizationAlgorithm oa:
    :param BackPropagationNetwork network:
    :param str oaName:
    :param list[Instance] instances:
    :param AbstractErrorMeasure measure:
    """
    print "\nError results for %s\n---------------------------" % (oaName,)
    
    error = [0.]*TRAINING_ITERATIONS
    for iteration in xrange(TRAINING_ITERATIONS):
        oa.train()
        for idx, instance in enumerate(instances):
            network.setInputValues(instance.getData())
            network.run()

            output = instance.getLabel()
            output_values = network.getOutputValues()
            example = Instance(output_values, Instance(output_values.get(0)))
            # error += measure.value(output, example)
            error[iteration] += measure.value(output, example)
        
        error[iteration] /= len(instances)
        print "%f" % error[iteration]
        
    return error


def main():
    """Run algorithms on the abalone dataset."""
    train_instances = initialize_instances(INPUT_FILE_TRAIN)
    test_instances = initialize_instances(INPUT_FILE_TEST)
    factory = BackPropagationNetworkFactory()
    measure = SumOfSquaresError()
    data_set_train = DataSet(train_instances)

    networks = []  # BackPropagationNetwork
    nnop = []  # NeuralNetworkOptimizationProblem
    oa = []  # OptimizationAlgorithm
    oa_names = ["GA"]
    results = ""

    for name in oa_names:
        classification_network = factory.createClassificationNetwork([INPUT_LAYER, HIDDEN_LAYER1, HIDDEN_LAYER2, OUTPUT_LAYER])
        networks.append(classification_network)
        nnop.append(NeuralNetworkOptimizationProblem(data_set_train, classification_network, measure))

    oa.append(StandardGeneticAlgorithm(200, 100, 10, nnop[0]))

    for i, name in enumerate(oa_names):
        start = time.time()
        correct = 0
        incorrect = 0

        losses = train(oa[i], networks[i], oa_names[i], train_instances, measure)
        end = time.time()
        training_time = end - start
        
        # Save losses to a csv file
        save_list(losses, 'nn_ga_loss.csv')

        optimal_instance = oa[i].getOptimal()
        networks[i].setWeights(optimal_instance.getData())

        start = time.time()
        for instance in test_instances:
            networks[i].setInputValues(instance.getData())
            networks[i].run()

            predicted = instance.getLabel().getContinuous()
            actual = networks[i].getOutputValues().get(0)

            if abs(predicted - actual) < 0.5:
                correct += 1
            else:
                incorrect += 1

        end = time.time()
        testing_time = end - start

        results += "\nResults for %s: \nCorrectly classified %d instances." % (name, correct)
        results += "\nIncorrectly classified %d instances.\nPercent correctly classified: %0.03f%%" % (incorrect, float(correct)/(correct+incorrect)*100.0)
        results += "\nTraining time: %0.03f seconds" % (training_time,)
        results += "\nTesting time: %0.03f seconds\n" % (testing_time,)

    print results


if __name__ == "__main__":
    main()

