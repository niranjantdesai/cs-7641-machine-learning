import sys
import os
import time
import csv

import java.io.FileReader as FileReader
import java.io.File as File
import java.lang.String as String
import java.lang.StringBuffer as StringBuffer
import java.lang.Boolean as Boolean
import java.util.Random as Random

import sys
sys.path.insert(0, '../bin')

import dist.DiscreteDependencyTree as DiscreteDependencyTree
import dist.DiscreteUniformDistribution as DiscreteUniformDistribution
import dist.Distribution as Distribution
import opt.DiscreteChangeOneNeighbor as DiscreteChangeOneNeighbor
import opt.EvaluationFunction as EvaluationFunction
import opt.GenericHillClimbingProblem as GenericHillClimbingProblem
import opt.HillClimbingProblem as HillClimbingProblem
import opt.NeighborFunction as NeighborFunction
import opt.RandomizedHillClimbing as RandomizedHillClimbing
import opt.SimulatedAnnealing as SimulatedAnnealing
import opt.example.FourPeaksEvaluationFunction as FourPeaksEvaluationFunction
import opt.ga.CrossoverFunction as CrossoverFunction
import opt.ga.SingleCrossOver as SingleCrossOver
import opt.ga.DiscreteChangeOneMutation as DiscreteChangeOneMutation
import opt.ga.GenericGeneticAlgorithmProblem as GenericGeneticAlgorithmProblem
import opt.ga.GeneticAlgorithmProblem as GeneticAlgorithmProblem
import opt.ga.MutationFunction as MutationFunction
import opt.ga.StandardGeneticAlgorithm as StandardGeneticAlgorithm
import opt.ga.UniformCrossOver as UniformCrossOver
import opt.prob.GenericProbabilisticOptimizationProblem as GenericProbabilisticOptimizationProblem
import opt.prob.MIMIC as MIMIC
import opt.prob.ProbabilisticOptimizationProblem as ProbabilisticOptimizationProblem
import shared.FixedIterationTrainer as FixedIterationTrainer
import opt.example.ContinuousPeaksEvaluationFunction as ContinuousPeaksEvaluationFunction
from array import array



"""
Commandline parameter(s):
   none
"""

N_list = range(50, 201, 25)
num_runs = 10
rhc_max = [0]*len(N_list)
sa_max = [0]*len(N_list)
ga_max = [0]*len(N_list)
rhc_time = [0]*len(N_list)
sa_time = [0]*len(N_list)
ga_time = [0]*len(N_list)
for i in range(num_runs):
    print "Run # " + str(i)
    for idx, N in enumerate(N_list):
        T=N/10
        fill = [2] * N
        ranges = array('i', fill)

        ef = ContinuousPeaksEvaluationFunction(T)
        odd = DiscreteUniformDistribution(ranges)
        nf = DiscreteChangeOneNeighbor(ranges)
        mf = DiscreteChangeOneMutation(ranges)
        cf = SingleCrossOver()
        df = DiscreteDependencyTree(.1, ranges)
        hcp = GenericHillClimbingProblem(ef, odd, nf)
        gap = GenericGeneticAlgorithmProblem(ef, odd, mf, cf)
        pop = GenericProbabilisticOptimizationProblem(ef, odd, df)

        rhc = RandomizedHillClimbing(hcp)
        fit = FixedIterationTrainer(rhc, 50000)
        start = time.time()
        fit.train()
        end = time.time()
        rhc_time[idx] += end - start
        rhc_optimal = ef.value(rhc.getOptimal())
        if rhc_optimal > rhc_max[idx]:
            rhc_max[idx] = rhc_optimal
        print "RHC: " + str(rhc_optimal)

        sa = SimulatedAnnealing(1E11, .95, hcp)
        fit = FixedIterationTrainer(sa, 50000)
        start = time.time()
        fit.train()
        end = time.time()
        sa_time[idx] += end - start
        sa_optimal = ef.value(sa.getOptimal())
        if sa_optimal > sa_max[idx]:
            sa_max[idx] = sa_optimal
        print "SA: " + str(sa_optimal)
        
        ga = StandardGeneticAlgorithm(200, 100, 10, gap)
        fit = FixedIterationTrainer(ga, 50000)
        start = time.time()
        fit.train()
        end = time.time()
        ga_time[idx] += end - start
        ga_optimal = ef.value(ga.getOptimal())
        if ga_optimal > ga_max[idx]:
            ga_max[idx] = ga_optimal
        print "GA: " + str(ga_optimal)
        
        print
    print
    
with open('continuouspeaks_fitness.txt', 'wb') as fitness_file:
    fitness_writer = csv.writer(fitness_file)
    for i in range(len(N_list)):
        fitness_writer.writerow([str(N_list[i]), str(rhc_max[i]), str(sa_max[i]), str(ga_max[i])])
        
with open('continuouspeaks_time.txt', 'wb') as time_file:
    time_writer = csv.writer(time_file)
    for i in range(len(N_list)):
        time_writer.writerow([str(N_list[i]), str(rhc_time[i]/len(N_list)), str(sa_time[i]/len(N_list)), str(ga_time[i]/len(N_list))])
