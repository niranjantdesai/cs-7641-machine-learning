import sys
import os
import time
import csv

import java.io.FileReader as FileReader
import java.io.File as File
import java.lang.String as String
import java.lang.StringBuffer as StringBuffer
import java.lang.Boolean as Boolean
import java.util.Random as Random

import sys
sys.path.insert(0, '../bin')

import dist.DiscreteDependencyTree as DiscreteDependencyTree
import dist.DiscreteUniformDistribution as DiscreteUniformDistribution
import dist.Distribution as Distribution
import opt.DiscreteChangeOneNeighbor as DiscreteChangeOneNeighbor
import opt.EvaluationFunction as EvaluationFunction
import opt.GenericHillClimbingProblem as GenericHillClimbingProblem
import opt.HillClimbingProblem as HillClimbingProblem
import opt.NeighborFunction as NeighborFunction
import opt.RandomizedHillClimbing as RandomizedHillClimbing
import opt.SimulatedAnnealing as SimulatedAnnealing
import opt.example.FourPeaksEvaluationFunction as FourPeaksEvaluationFunction
import opt.ga.CrossoverFunction as CrossoverFunction
import opt.ga.SingleCrossOver as SingleCrossOver
import opt.ga.DiscreteChangeOneMutation as DiscreteChangeOneMutation
import opt.ga.GenericGeneticAlgorithmProblem as GenericGeneticAlgorithmProblem
import opt.ga.GeneticAlgorithmProblem as GeneticAlgorithmProblem
import opt.ga.MutationFunction as MutationFunction
import opt.ga.StandardGeneticAlgorithm as StandardGeneticAlgorithm
import opt.ga.UniformCrossOver as UniformCrossOver
import opt.prob.GenericProbabilisticOptimizationProblem as GenericProbabilisticOptimizationProblem
import opt.prob.ProbabilisticOptimizationProblem as ProbabilisticOptimizationProblem
import shared.FixedIterationTrainer as FixedIterationTrainer

from array import array


"""
Commandline parameter(s):
   none
"""

N_list = range(20, 101, 10)
#N_list = range(90, 101, 10)
num_runs = 1
rhc_sum = [0]*len(N_list)
sa_sum = [0]*len(N_list)
ga_sum = [0]*len(N_list)
rhc_max = [0]*len(N_list)
sa_max = [0]*len(N_list)
ga_max = [0]*len(N_list)
rhc_time = [0]*len(N_list)
sa_time = [0]*len(N_list)
ga_time = [0]*len(N_list)
for i in range(num_runs):
    print "Run # " + str(i)
    for idx, N in enumerate(N_list):
        T = N/5
        print "N = " + str(N)
        print "T = " + str(T)
        fill = [2] * N
        ranges = array('i', fill)

        ef = FourPeaksEvaluationFunction(T)
        odd = DiscreteUniformDistribution(ranges)
        nf = DiscreteChangeOneNeighbor(ranges)
        mf = DiscreteChangeOneMutation(ranges)
        cf = SingleCrossOver()
        df = DiscreteDependencyTree(.1, ranges)
        hcp = GenericHillClimbingProblem(ef, odd, nf)
        gap = GenericGeneticAlgorithmProblem(ef, odd, mf, cf)
        pop = GenericProbabilisticOptimizationProblem(ef, odd, df)

        rhc = RandomizedHillClimbing(hcp)
        fit = FixedIterationTrainer(rhc, 400000)
        start = time.time()
        fit.train()
        end = time.time()
        rhc_time[idx] += end - start
        rhc_optimal = ef.value(rhc.getOptimal())
        rhc_sum[idx] += rhc_optimal
        if rhc_optimal > rhc_max[idx]:
            rhc_max[idx] = rhc_optimal
        print "RHC: " + str(rhc_optimal)

        sa = SimulatedAnnealing(1E11, .95, hcp)
        fit = FixedIterationTrainer(sa, 400000)
        start = time.time()
        fit.train()
        end = time.time()
        sa_time[idx] += end - start
        sa_optimal = ef.value(sa.getOptimal())
        sa_sum[idx] += sa_optimal
        if sa_optimal > sa_max[idx]:
            sa_max[idx] = sa_optimal
        print "SA: " + str(sa_optimal)

        ga = StandardGeneticAlgorithm(200, 100, 10, gap)
        fit = FixedIterationTrainer(ga, 400000)
        start = time.time()
        fit.train()
        end = time.time()
        ga_time[idx] += end - start
        ga_optimal = ef.value(ga.getOptimal())
        ga_sum[idx] += ga_optimal
        if ga_optimal > ga_max[idx]:
            ga_max[idx] = ga_optimal
        print "GA: " + str(ga_optimal)
        
        print
    print
        
rhc_avg = [x / num_runs for x in rhc_sum]
sa_avg = [x / num_runs for x in sa_sum]
ga_avg = [x / num_runs for x in ga_sum]

for idx, N in enumerate(N_list):
    T = N / 5
    print "N = " + str(N)
    print "T = " + str(T)
    print "RHC average performance: " + str(rhc_avg[idx])
    print "SA average performance: " + str(sa_avg[idx])
    print "GA average performance: " + str(ga_avg[idx])
    print "RHC best performance: " + str(rhc_max[idx])
    print "SA best performance: " + str(sa_max[idx])
    print "GA best performance: " + str(ga_max[idx])
    print
    
for i in range(len(N_list)):
    print('RHC: %f' % rhc_time[i])
    print('SA: %f' % sa_time[i])
    print('GA: %f' % ga_time[i])
    print
    
with open('fourpeaks_fitness.csv', 'w') as csvfile:
    for i in range(len(N_list)):
        csvfile.write("%s,%s,%s\n" % (N_list[i], rhc_max[i], sa_max[i], ga_max[i]))
        
with open('fourpeaks_time.csv', 'w') as csvfile:
    for i in range(len(N_list)):
        print('RHC: %f' % rhc_time[i])
        print('SA: %f' % sa_time[i])
        print('GA: %f' % ga_time[i])
        csvfile.write("%s,%s,%s\n" % (N_list[i], rhc_time[i]/len(N_list), sa_time[i]/len(N_list), ga_time[i]/len(N_list)))
