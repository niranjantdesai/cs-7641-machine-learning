Run the following files with the command python <filename>
randomized_hill_climbing.py: Randomized hill climbing to train the neural network
simulated_annealing.py: Simulated annealing to train the neural network

Run the following files in the ABAGAIL directory with the command jython <filename> (Java and Jython have to be installed first)
jython/abalone_test_copy.py: Genetic algorithm to train the neural network
jython/fourpeaks_test.py: Four peaks problem
jython/continuouspeaks_test.py: Continuous peaks problem